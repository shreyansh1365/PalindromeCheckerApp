# ==========================
# Database Configuration
# ==========================

DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "midhani",
    "database": "usb_monitor"
}


# ==========================
# Monitoring Settings
# ==========================

SCAN_INTERVAL = 1          # Seconds


# ==========================
# Logging
# ==========================

LOG_FILE = "logs/monitor.log"


# ==========================
# Hash Algorithm
# ==========================

HASH_ALGORITHM = "sha256"


# ==========================
# Device Code Prefix
# ==========================

DEVICE_PREFIX = "DEV"


# ==========================
# Supported File Systems
# ==========================

SUPPORTED_FILESYSTEMS = [
    "NTFS",
    "FAT32",
    "exFAT"
]