import mysql.connector

try:
    print("Starting database connection test...")

    conn = mysql.connector.connect(
        host="10.16.2.247",
        port=3306,
        user="usb_agent",
        password="UsbAgent@2026",
        database="usb_monitor",
        connection_timeout=5
    )

    print("SUCCESS: PC2 connected to PC1 MySQL database")

    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM usb_logs")

    count = cursor.fetchone()[0]

    print("USB logs count:", count)

    cursor.close()
    conn.close()

    print("Connection test completed successfully.")

except Exception as e:
    print("CONNECTION FAILED:")
    print(type(e).__name__)
    print(e)