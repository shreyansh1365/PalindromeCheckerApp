# ==========================
# Database Configuration
# ==========================

DB_CONFIG = {
    "host": "10.16.2.246",
    "port": 3306,
    "user": "usb_agent",
    "password": "UsbAgent@2026",
    "database": "usb_monitor",
    "connection_timeout": 5,
    "use_pure": True,
    "ssl_disabled": True
}


# ==========================
# Monitoring Settings
# ==========================

SCAN_INTERVAL = 1          # Seconds


# ==========================
# Logging
# ==========================

LOG_FILE = "logs/monitor.log"


# ==========================
# Hash Algorithm
# ==========================

HASH_ALGORITHM = "sha256"


# ==========================
# Device Code Prefix
# ==========================

DEVICE_PREFIX = "DEV"


# ==========================
# Supported File Systems
# ==========================

SUPPORTED_FILESYSTEMS = [
    "NTFS",
    "FAT32",
    "exFAT"
]